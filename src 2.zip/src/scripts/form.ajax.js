function sendForm(e) {
  e.preventDefault();

  $.ajax({
    URL: "php/server.php",
    method: "POST", //GET
    dataType: "text", // json,xml,html,text,script
    data: $(this).serialize(),
    beforeSend: function(){

    },
    error: function(){

    },
success: function(){

},

    
  });
}

$(".send").on("submit", sendForm());
