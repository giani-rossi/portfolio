<?php
$nombre = $_POST[$nombre];
$mensaje = $_POST[$mensaje];
$metodo = $_POST['metodo'];
echo 'Los datos han pasado por el server';
?>